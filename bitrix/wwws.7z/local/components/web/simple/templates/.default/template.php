<?php
echo '<pre>'; print_r($arResult); echo '</pre>';


?>

<div style="width: 100px;
height: 100px;
background: <?=$arParams['COLOR']?>">
    <?=$arResult['COLOR_NAME']?>
</div>

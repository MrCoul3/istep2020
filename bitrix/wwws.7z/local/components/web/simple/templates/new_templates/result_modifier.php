<?php
print_r($arParams['SIZE'] );
$arParams['SIZE'] = $arParams['SIZE'] * 1.2;
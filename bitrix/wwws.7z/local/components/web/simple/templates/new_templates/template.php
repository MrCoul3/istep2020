<?php
echo '<pre>'; print_r($arResult); echo '</pre>';


?>

<h1>new temp</h1>

<div style="width: <?=$arParams['SIZE']?>;
height: 100px;
background: <?=$arParams['COLOR']?>">
    <?=$arResult['COLOR_NAME']?>
</div>


<footer>
    <h1>я footer!</h1>
</footer>
</body>
</html>